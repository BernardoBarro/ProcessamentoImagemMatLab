import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Exercicio7 {
	public static void main(String[] args) {

		Locale.setDefault(Locale.US);
		Scanner input = new Scanner(System.in);

		int m = input.nextInt();
		int n = input.nextInt();

		Random random = new Random();

		int[][] matriz1 = new int[m][n];
		int[][] matriz2 = new int[m][n];
		int[][] underflow = new int[m][n];
		int[][] overflow = new int[m][n];

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				matriz1[i][j] = random.nextInt(255);
				matriz2[i][j] = random.nextInt(255);
			}
		}
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				overflow[i][j] = matriz1[i][j] + matriz2[i][j];

				if ((matriz1[i][j] + matriz2[i][j]) > 255) {
					underflow[i][j] = 255;
				} else {
					underflow[i][j] = matriz1[i][j] + matriz2[i][j];
				}
			}
		}

		System.out.println("Overflow");
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(overflow[i][j] + " ");
			}
			System.out.println();
		}

		System.out.println();
		
		System.out.println("Underflow");
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(underflow[i][j] + " ");
			}
			System.out.println();
		}
		
	}
}
